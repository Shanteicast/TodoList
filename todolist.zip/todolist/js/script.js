

$(document).ready(function() {
    let currentDay = 'Mon';
    loadTasks(currentDay);

    $(document).ready(function() {
        $('.btn').on('mousedown', function() {
            $(this).css('transform', 'scale(0.9)');
        });
    
        $('.btn').on('mouseup', function() {
            $(this).css('transform', 'scale(1)');
        });
    });


    $('.day').on('click', function() {
        $('.day').removeClass('active');
        $(this).addClass('active');
        currentDay = $(this).data('day');
        loadTasks(currentDay);
    });

    $('#taskForm').on('submit', function(event) {
        event.preventDefault();
        const taskName = $('#taskName').val();
        const taskType = $('#taskType').val();

        $.ajax({
            url: 'php/add_task.php',
            method: 'POST',
            data: { name: taskName, type: taskType, day: currentDay },
            success: function(response) {
                $('#taskModal').modal('hide');
                $('#taskForm')[0].reset();
                loadTasks(currentDay);
            }
        });
    });

    $('#editTaskForm').on('submit', function(event) {
        event.preventDefault();
        const taskId = $('#editTaskId').val();
        const taskName = $('#editTaskName').val();
        const taskType = $('#editTaskType').val();

        $.ajax({
            url: 'php/update_task.php',
            method: 'POST',
            data: { id: taskId, name: taskName, type: taskType },
            success: function(response) {
                $('#editTaskModal').modal('hide');
                $('#editTaskForm')[0].reset();
                loadTasks(currentDay);
            }
        });
    });

    function loadTasks(day) {
        $.ajax({
            url: 'php/get_tasks.php',
            method: 'GET',
            data: { day: day },
            success: function(response) {
                const tasks = JSON.parse(response);
                renderTasks(tasks);
            }
        });
    }

    function renderTasks(tasks) {
        const topPriorityList = $('#top-priority-list');
        const otherTaskList = $('#other-task-list');
        const eventList = $('#event-list');

        topPriorityList.empty();
        otherTaskList.empty();
        eventList.empty();

        tasks.topPriorities.forEach(task => {
            topPriorityList.append(`
                <li data-id="${task.id}">
                    ${task.name}
                    <button class="btn btn-sm btn-warning edit-task">Edit</button>
                    <button class="btn btn-sm btn-danger delete-task">Delete</button>
                </li>`);
        });

        tasks.otherTasks.forEach(task => {
            otherTaskList.append(`
                <li data-id="${task.id}">
                    ${task.name}
                    <button class="btn btn-sm btn-warning edit-task">Edit</button>
                    <button class="btn btn-sm btn-danger delete-task">Delete</button>
                </li>`);
        });

        tasks.events.forEach(task => {
            eventList.append(`
                <li data-id="${task.id}">
                    ${task.name}
                    <button class="btn btn-sm btn-warning edit-task">Edit</button>
                    <button class="btn btn-sm btn-danger delete-task">Delete</button>
                </li>`);
        });

        $('.edit-task').on('click', function() {
            const taskId = $(this).parent().data('id');
            $.ajax({
                url: 'php/get_task.php',
                method: 'GET',
                data: { id: taskId },
                success: function(response) {
                    const task = JSON.parse(response);
                    $('#editTaskId').val(task.id);
                    $('#editTaskName').val(task.name);
                    $('#editTaskType').val(task.type);
                    $('#editTaskModal').modal('show');
                }
            });
        });

        $('.delete-task').on('click', function() {
            const taskId = $(this).parent().data('id');
            $.ajax({
                url: 'php/delete_task.php',
                method: 'POST',
                data: { id: taskId },
                success: function(response) {
                    loadTasks(currentDay);
                }
            });
        });
    }
});




