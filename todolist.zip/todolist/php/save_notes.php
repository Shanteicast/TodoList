<?php
// Database connection setup
include 'db.php';

$day = $_POST['day'];
$notes = $_POST['notes'];

// Check if notes already exist for the day
$query = "SELECT id FROM daily_notes WHERE day = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("s", $day);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update existing notes
    $query = "UPDATE daily_notes SET notes = ? WHERE day = ?";
} else {
    // Insert new notes
    $query = "INSERT INTO daily_notes (notes, day) VALUES (?, ?)";
}

$stmt = $mysqli->prepare($query);
$stmt->bind_param("ss", $notes, $day);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to save notes']);
}

$stmt->close();
$mysqli->close();
?>
