<?php
include 'db.php';  // Adjust this path as necessary

$day = $_GET['day'] ?? 'Mon';  // Default to Monday if no day is provided

$query = "SELECT notes FROM daily_notes WHERE day = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("s", $day);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode(['notes' => $row['notes']]);
} else {
    echo json_encode(['notes' => '']);  // Send empty string if no notes found
}

$stmt->close();
$mysqli->close();
?>
