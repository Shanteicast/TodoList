<?php
require 'db.php';

$name = $_POST['name'];
$type = $_POST['type'];
$day = $_POST['day'];

$stmt = $pdo->prepare("INSERT INTO tasks (name, type, day) VALUES (?, ?, ?)");
$stmt->execute([$name, $type, $day]);

echo 'Task added successfully';
?>
