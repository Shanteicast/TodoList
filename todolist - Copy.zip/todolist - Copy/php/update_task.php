<?php
require 'db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$type = $_POST['type'];

$stmt = $pdo->prepare("UPDATE tasks SET name = ?, type = ? WHERE id = ?");
$stmt->execute([$name, $type, $id]);

echo 'Task updated successfully';
?>
