<?php
require 'db.php';

$day = $_GET['day'];

$stmt = $pdo->prepare("SELECT * FROM tasks WHERE day = ?");
$stmt->execute([$day]);
$tasks = $stmt->fetchAll();

$topPriorities = [];
$otherTasks = [];
$events = [];

foreach ($tasks as $task) {
    if ($task['type'] == 'top_priority') {
        $topPriorities[] = $task;
    } elseif ($task['type'] == 'other_task') {
        $otherTasks[] = $task;
    } elseif ($task['type'] == 'event') {
        $events[] = $task;
    }
}

echo json_encode([
    'topPriorities' => $topPriorities,
    'otherTasks' => $otherTasks,
    'events' => $events,
]);
?>
